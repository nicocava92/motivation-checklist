namespace LaheyHealth.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class UpdateScores : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
